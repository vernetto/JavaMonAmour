package com.pierre.sudoku;

public enum SudokuValidationResult {
	SUCCESS, FAILURE
}
